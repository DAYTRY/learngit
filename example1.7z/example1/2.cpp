#include<cstdio>
#include<algorithm>
#include<stack>
#include<iostream>
#include<malloc.h>
#include <cstdlib>
#define N 20
using namespace std;



 struct ListNode {
        int data;
        struct ListNode *next;
      };
typedef struct ListNode   LinkList; 
 LinkList * head,* tail;

LinkList* oddEvenList(LinkList* head){
			if(!head)
			return head;

			LinkList* first = head; 
			LinkList* second = head->next;
		    LinkList* temp = second;
			while(second && second->next){
				second->next = first->next;
				second = second->next;
				first->next = second->next;
				first = first->next;		
			}
			first->next = temp;
			return head;
		}	


void print_link(LinkList  * head)
{
	
	while (head)
	{
		printf("%d ", head->data);
		head = head->next;
	}
	printf("\n");
}

LinkList* newnode()
{
   LinkList* u=(LinkList*) malloc(sizeof(LinkList));//����һ����̬��ַ���������Ҫ�����ͬʱҪ��cstdlibͷ�ļ� 
    u->next=NULL;
}

int main(){
	printf("���룺");
	 head=newnode();//����һ���µ�ָ�롣 
    tail=head;
    for (int i=1;i<=N;i++)
        {
            tail->next=newnode();
            tail=tail->next;
            scanf("%d",&tail->data);    
        }
        
	printf("�����");
	
   LinkList* h= oddEvenList(head);
   print_link(h);

	
	 
	
	
}
