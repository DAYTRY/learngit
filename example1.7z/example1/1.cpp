#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 80 

int firstUniqChar(char* s) {
    int hashtable[256];
    int i,l=strlen(s),ret=-1;
    memset(hashtable,0,sizeof(int)*256);

    if(l){
        for(i=0;i<l;i++){
          hashtable[s[i]]++;
        }
        for(i=0;i<l;i++) {
            if(hashtable[s[i]]==1){          
                ret = i;
                break;
            }
        }
    }
    return ret;
}


int main(){
	char s[N];
	printf("s=");
	gets(s);
	printf("���أ�");
	printf("%d\n",firstUniqChar(s)); 	
} 
